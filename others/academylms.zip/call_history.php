<?php
require __DIR__ . '/vendor/autoload.php';
use Twilio\Rest\Client;

// Your Account SID and Auth Token from twilio.com/console
$account_sid = 'AC05436b48aff36c5f3d0fdc99c439bbe5';
$auth_token = '3394e7cdcff93e812319c6b6f771fefa';
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

// A Twilio number you own with SMS capabilities
$twilio_number = "+14067477770";

$twilio = new Client($account_sid, $auth_token);

$calls = $twilio->calls
                   ->read([], 20);

				   
$history = [] ;
foreach ($calls as $record) {
	
   // print($record->sid . "\n" );
//	print($record->to  . "\n" );
//	print($record->duration  . "\n" );
//	print($record->status  . "\n" );
	$v = new stdClass ;
	$v->sid = $record->sid ;
	$v->to = $record->to ;
	$v->duration = $record->duration ;
	$history [] = $v ;
}

print( json_encode( $history ) );



