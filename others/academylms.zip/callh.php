<?php 
require __DIR__ . '/vendor/autoload.php';

use Twilio\Rest\Client;

// Find your Account Sid and Auth Token at twilio.com/console
// and set the environment variables. See http://twil.io/secure
$sid = 'AC05436b48aff36c5f3d0fdc99c439bbe5';
$token = '3394e7cdcff93e812319c6b6f771fefa';
$twilio = new Client($sid, $token);

$call = $twilio->calls
               ->create("+8801515233939", // to
						"+14067477770",   // from 
                        ["url" => "http://demo.twilio.com/docs/voice.xml"]
               );

print($call->sid);