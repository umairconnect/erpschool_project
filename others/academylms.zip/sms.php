<?php
require __DIR__ . '/vendor/autoload.php';
use Twilio\Rest\Client;

// Your Account SID and Auth Token from twilio.com/console
$account_sid = 'AC05436b48aff36c5f3d0fdc99c439bbe5';
$auth_token = '3394e7cdcff93e812319c6b6f771fefa';
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

// A Twilio number you own with SMS capabilities
$twilio_number = "+14067477770";

$client = new Client($account_sid, $auth_token);
$client->messages->create(
    // Where to send a text message (your cell phone?)
    '+8801703254064',
    array(
        'from' => $twilio_number,
        'body' => 'working'
    )
);



