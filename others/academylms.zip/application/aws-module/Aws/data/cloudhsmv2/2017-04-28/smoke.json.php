<?php
// This file was auto-generated from sdk-root/src/data/cloudhsmv2/2017-04-28/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeClusters', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'ListTags', 'input' => [ 'ResourceId' => 'bogus-arn', ], 'errorExpectedFromService' => true, ], ],];
