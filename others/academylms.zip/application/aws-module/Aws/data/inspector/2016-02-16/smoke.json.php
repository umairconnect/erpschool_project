<?php
// This file was auto-generated from sdk-root/src/data/inspector/2016-02-16/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListAssessmentTemplates', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'ListTagsForResource', 'input' => [ 'resourceArn' => 'fake-arn', ], 'errorExpectedFromService' => true, ], ],];
