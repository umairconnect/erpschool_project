<div class="row">
	<div class="col-md-12">
		<h4 class="mb-2"><?php echo get_phrase('outcomes'); ?></h4>
		<?php echo $course['outcomes']; ?>
	</div>
	<div class="col-md-12 mt-4">
		<h4 class="mb-2"><?php echo get_phrase('descriptions'); ?></h4>
		<?php echo $course['description']; ?>
	</div>
</div>
	